javac -g -d classes  org/garret/perst/*.java org/garret/perst/impl/*.java cdc/org/garret/perst/impl/*.java xml/org/garret/perst/impl/*.java 
jar cvf ../lib/perst11.jar org/garret/perst/*.class org/garret/perst/impl/*.class dc/org/garret/perst/impl/*.class xml/org/garret/perst/impl/*.class
