package org.garret.perst;

import java.util.Enumeration;

/**
 * Class providing both JDK 1.2 java.util.Iterator and JDK 1.1 java.util.Enumeation interfaces
 */
public abstract class Iterator implements Enumeration {
    /**
     * Get OID of the next object
     * @return OID of the the next element in the iteration or 0 if iteration has no more objects.
     */
    abstract public int nextOid();

    /**
     * Tests if this enumeration contains more elements.
     *
     * @return  <code>true</code> if and only if this enumeration object
     *           contains at least one more element to provide;
     *          <code>false</code> otherwise.
     */
    public boolean hasMoreElements() { 
        return hasNext();
    }

    /**
     * Returns the next element of this enumeration if this enumeration
     * object has at least one more element to provide.
     *
     * @return     the next element of this enumeration.
     * @exception  NoSuchElementException  if no more elements exist.
     */
    public Object nextElement() { 
        return next();
    }

    /**
     * Returns <tt>true</tt> if the iteration has more elements. (In other
     * words, returns <tt>true</tt> if <tt>next</tt> would return an element
     * rather than throwing an exception.)
     *
     * @return <tt>true</tt> if the iterator has more elements.
     */
    public abstract boolean hasNext();

    /**
     * Returns the next element in the iteration.
     *
     * @return the next element in the iteration.
     * @exception NoSuchElementException iteration has no more elements.
     */
    public abstract Object next();

    /**
     * 
     * Removes from the underlying collection the last element returned by the
     * iterator (optional operation).  This method can be called only once per
     * call to <tt>next</tt>.  The behavior of an iterator is unspecified if
     * the underlying collection is modified while the iteration is in
     * progress in any way other than by calling this method.
     *
     * @exception UnsupportedOperationException if the <tt>remove</tt>
     *		  operation is not supported by this Iterator.
     
     * @exception IllegalStateException if the <tt>next</tt> method has not
     *		  yet been called, or the <tt>remove</tt> method has already
     *		  been called after the last call to the <tt>next</tt>
     *		  method.
     */
    public abstract void remove();

    /**
     * Count number of selected elements
     * Please notice that the current position of iterator is moved to the end after execution
     * of this method and you can not call next() any more
     * @return number of selected elements
     */
    public int count() { 
        int n = 0;
        int oid;
        while ((oid = nextOid()) != 0) { 
            n += 1;
        }
        return n;
    }
}
