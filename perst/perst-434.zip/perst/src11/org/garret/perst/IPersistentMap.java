package org.garret.perst;

import java.util.*;

/**
 * Interface of persistent map
 */
public interface IPersistentMap extends Map, IPersistent, IResource
{
} 