package org.garret.rdf;

import org.garret.perst.*;


/**
 * Property definition
 */
public class PropDef extends Persistent {
   /**
    * Name of the property
    */
    public String name;
}    
