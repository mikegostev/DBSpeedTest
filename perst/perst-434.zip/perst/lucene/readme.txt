PerstDirectory class implements org.apache.lucene.store.Directory interface and allows 
to keep directory in perst database.
PerstIndexer and PerstSearched are examples of building indices and performing search
using Lucene search engine with data stored in Perst. 
