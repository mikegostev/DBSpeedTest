package org.garret.perst.impl;

public interface LoadFactory { 
    Object create(ClassDescriptor desc);
}