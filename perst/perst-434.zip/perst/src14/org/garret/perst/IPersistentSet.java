package org.garret.perst;

import java.util.Set;

/**
 * Interface of persistent set. 
 */
public interface IPersistentSet extends IPersistent, IResource, ITable, Set {}
